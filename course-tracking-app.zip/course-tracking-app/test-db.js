const { Sequelize, DataTypes } = require('sequelize');

// Configure database connection
const sequelize = new Sequelize('course_tracking', 'postgres', 'admin', {
  host: '127.0.0.1',
  dialect: 'postgres',
});

const Course = sequelize.define('Course', {
  name: { type: DataTypes.STRING, allowNull: false }
});

const Lecturer = sequelize.define('Lecturer', {
  name: { type: DataTypes.STRING, allowNull: false }
});

const CourseLecturer = sequelize.define('CourseLecturer', {});

// Define associations
Course.belongsToMany(Lecturer, { through: CourseLecturer });
Lecturer.belongsToMany(Course, { through: CourseLecturer });

async function testDatabase() {
  try {
    // Synchronize models with the database
    await sequelize.sync({ force: true }); // Use force: true for testing to drop and recreate tables
    console.log('Database synchronized');

    // Create a course
    const course = await Course.create({ name: 'Introduction to Programming' });
    console.log('Course created:', course.toJSON());

    // Create a lecturer
    const lecturer = await Lecturer.create({ name: 'Dr. Smith' });
    console.log('Lecturer created:', lecturer.toJSON());

    // Associate course with lecturer
    await course.addLecturer(lecturer);
    console.log('Course and Lecturer associated');

    // Fetch and display courses with lecturers
    const courses = await Course.findAll({ include: Lecturer });
    console.log('Courses with Lecturers:', JSON.stringify(courses, null, 2));
  } catch (error) {
    console.error('Error testing database:', error);
  } finally {
    await sequelize.close();
  }
}

testDatabase();
