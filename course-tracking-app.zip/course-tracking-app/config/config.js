module.exports = {
    development: {
      username: 'postgres',
      password: 'admin',
      database: 'course_tracking',
      host: '127.0.0.1',
      dialect: 'postgres'
    },
    
  };
  