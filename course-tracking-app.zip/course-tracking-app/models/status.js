const express = require('express');
const router = express.Router();
const { Status } = require('../models');

router.get('/', (req, res) => {
  res.render('status-update');
});

router.post('/update', async (req, res) => {
  const { courseId, lecturerId, statusUpdates } = req.body;
  await Status.update(statusUpdates, { where: { course_id: courseId, lecturer_id: lecturerId } });
  res.redirect('/status');
});

module.exports = router;
