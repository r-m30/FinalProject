const { Sequelize, DataTypes } = require('sequelize');
const config = require('../config/config')[process.env.NODE_ENV || 'development'];
const sequelize = new Sequelize(config.database, config.username, config.password, config);

const Course = sequelize.define('Course', {
  name: { type: DataTypes.STRING, allowNull: false }
});

const Lecturer = sequelize.define('Lecturer', {
  name: { type: DataTypes.STRING, allowNull: false }
});

const Status = sequelize.define('Status', {
  course_id: { type: DataTypes.INTEGER, references: { model: Course, key: 'id' } },
  lecturer_id: { type: DataTypes.INTEGER, references: { model: Lecturer, key: 'id' } },
  started_date: { type: DataTypes.DATE },
  assignment_dates: { type: DataTypes.JSON },
  test_dates: { type: DataTypes.JSON },
  assignment_status: { type: DataTypes.JSON },
  test_status: { type: DataTypes.JSON },
  final_exam: { type: DataTypes.BOOLEAN },
  final_project: { type: DataTypes.BOOLEAN },
  final_exam_date: { type: DataTypes.DATE },
  final_project_date: { type: DataTypes.DATE },
  final_project_status: { type: DataTypes.STRING },
  marksheets_status: { type: DataTypes.STRING }
});

Course.belongsToMany(Lecturer, { through: 'CourseLecturer' });
Lecturer.belongsToMany(Course, { through: 'CourseLecturer' });

module.exports = { sequelize, Course, Lecturer, Status };
