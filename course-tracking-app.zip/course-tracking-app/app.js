const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { sequelize } = require('./models');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

const indexRoutes = require('./routes/index');
const hodRoutes = require('./routes/hod');
const lecturerRoutes = require('./routes/lecturer');
const statusRoutes = require('./routes/status');

app.use('/', indexRoutes);
app.use('/hod', hodRoutes);
app.use('/lecturer', lecturerRoutes);
app.use('/status', statusRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  await sequelize.sync();
});
