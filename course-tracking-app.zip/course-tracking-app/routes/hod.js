router.post('/allocate', async (req, res) => {
    try {
      const { courseName, lecturerId, semester } = req.body;
  
      // Validate inputs
      if (!courseName || isNaN(parseInt(lecturerId, 10))) {
        return res.status(400).send('Invalid input');
      }
  
      // Create course and allocate to lecturer
      const course = await Course.create({ name: courseName });
      await course.addLecturer(parseInt(lecturerId, 10));
  
      res.redirect('/hod');
    } catch (error) {
      console.error('Error allocating course:', error);
      res.status(500).send('Internal Server Error');
    }
  });
  